// import React, { useState } from 'react';
// import Chevron from '../images/chevron-top.svg';
// import Vector from '../images/Vector.svg';
// import Add from '../images/Add button.svg';
// import Color from '../images/Color Scheme.svg';
// import Frame6 from '../images/Frame 6.svg';
// import Trash from '../images/trash.svg';
// import empty from '../images/empty.svg';
// import Sun from '../images/sun.svg';
// import TrashRed from '../images/trash-red.svg';
// import Frame6Blue from '../images/Frame6-blue.svg';
// import './style.css';

// const MainNote = () => {
//   const [noteText, setNoteText] = useState('');
//   const [editIndex, setEditIndex] = useState(null);
//   const [isClicked, setIsClicked] = useState(false);
//   const [notes, setNotes] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [isBackgroundBlack, setIsBackgroundBlack] = useState(false);
//   const [searchText, setSearchText] = useState('');
//   const [modalColor, setModalColor] = useState('white');
//   const [trashHovered, setTrashHovered] = useState(false);
//   const [editHovered, setEditHovered] = useState(false);

//   const clickBackgroundHandler = () => {
//     setIsBackgroundBlack((prevState) => !prevState);
//     if (modalColor === 'white') {
//       setModalColor('black');
//     } else {
//       setModalColor('white');
//     }
//   };

//   const editNote = (index) => {
//     setNotes((previous) => {
    
//       const newNote = [...previous]

//       newNote[index] = {
//         ...newNote[index]
      
//       }
//       return newNote
//     })
//   }

//   const editNoteHandler = (e) => {
//     setEditIndex(e);
//   }


//   const addNoteHandler = () => {
//     if (noteText.trim() !== '') {
//       setNotes([...notes, noteText])
//       setNoteText('')
//       setShowModal(false)
//     }
//   }

//   const openModal = () => {
//     setShowModal(true);
//   }

//   const closeModal = () => {
//     setShowModal(false);
//   }



  
//   const modalStyle = {
//     background: isClicked ? 'var(--black)' : modalColor
//   }

//   const noteTitleChangeHandler = (event, index) => {
//     const newNote = [...notes];
//     newNote[index] = event.target.value;
//     setNotes(newNote);
//   };

//   const deleteNoteHandler = (index) => {
//     const newNote = [...notes];
//     newNote.splice(index, 1);
//     setNotes(newNote);
//   };

//   const filteredNotes = notes.filter((note) =>
//     note.toLowerCase().includes(searchText.toLowerCase())
//   );

//   return (
//     <div className='Main-light' style={{ background: isBackgroundBlack ? 'var(--black, #252525)' : '' }}>
//       <div className='CONTAINER-wrapper'>
//         <div className='CONTAINER'>
//           <div className='HEAD'>
//             <div className={`text-wrapper ${isBackgroundBlack ? 'white-text' : 'black-text'}`}>TODO LIST</div>
//             <header className='header'>
//               <div className={`search ${isBackgroundBlack ? 'white-background' : 'black-background'}`}>
//                 <input className='search-note' placeholder='Search note...' type='text' />
//                 <img className={`vector ${isBackgroundBlack ? 'black-vector' : 'white-vector'}`} alt='Vector' src={Vector}/>
//               </div>
//               <div className='select'>
//                 <div className='content'>
//                   <div className='all'>ALL</div>
//                   <img className='chevron-top' alt='Chevron top' src={Chevron} />
//                 </div>
//               </div>
//               <div className='color-scheme'>
//                 <img className='img' alt='img' src={isBackgroundBlack ? Sun : Color} onClick={clickBackgroundHandler} style={isClicked ? ({backgroundColor: `--black`}) :({backgroundColor: `--white`}) }/>
//               </div>
//             </header>
//           </div>
//           <div className='BODY'>
//             <div className='add-button' onClick={openModal}>
//               <img className='vector-2' alt='Vector' src={Add} />
//             </div>
//             {showModal && (
//               <div className='modal'>
//                 <div className='modal-content' style={modalStyle}>
//                   <h2 className={`new-note ${isBackgroundBlack ? 'white-text' : 'black-text'}`}>NEW NOTE</h2>
//                   <input
//                     type='text'
//                     placeholder='Input your note...'
//                     value={noteText}
//                     className='Input-note'
//                     onChange={(e) => setNoteText(e.target.value)}
//                   />
//                   <div className='button-container'>
//                     <button className={`cancel ${isBackgroundBlack ? 'white-back' : 'black-back'}`} onClick={closeModal}>
//                       Cancel
//                     </button>
//                     <button className='apply' onClick={addNoteHandler}>
//                       Apply
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             )}
//             <div className='LIST'>
              
//            {notes.length === 0 ? (
//     <div style={{ textAlign: 'center' }}>
//       <img src={empty} className='empty' alt='Empty' />
//       <h2 className={isBackgroundBlack ? 'white-text' : 'black-text'}>Empty...</h2>
//     </div>
//   ) : (
//     notes.map((note, index) => (
//         <div
//           key={index}
//           className={`note ${note.ticked ? 'ticked' : ''}`}
//           style={{ marginTop: '50px' }}
//         >
           
//           <div
//             className={`rectangle ${note.ticked ? 'purple' : ''}`}
            
//             onClick={() => editNote(index)}
//           >
//             <input type="checkbox" id="rectangle"></input>
//             {note.content}
//       {note.showIcon && <img src={Image18} className='Image18' alt='Icon' />}
//     </div>
//         {editIndex === index ? (
//           <input
//             type='text'
//             value={note}
//             onChange={(e) => noteTitleChangeHandler(e, index)}
//             onBlur={() => setEditIndex(null)} 
//           />
//         ) : (
//           <div className=''>{note}</div>
//         )}
//         <div className='options'>
//           <img
//             className='img-2'
//             alt='Frame'
//             src={editHovered ? Frame6 : Frame6Blue}
//             onMouseEnter={() => setEditHovered(true)}
//             onMouseLeave={() => setEditHovered(false)}
//             onClick={() => editNoteHandler(index)}
//           />
//           <img
//             className='img-2 trash'
//             alt='Trash svgrepo com'
//             src={trashHovered ? TrashRed : Trash}
//             onMouseEnter={() => setTrashHovered(true)}
//            onMouseLeave={() => setTrashHovered(false)}
//            onClick={() => deleteNoteHandler(index)}
//           />
//         </div>
//       </div>
//     ))
//   )}
// </div>

//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default MainNote;
import React, { useState } from 'react';
import Chevron from '../images/chevron-top.svg';
import Vector from '../images/Vector.svg';
import Add from '../images/Add button.svg';
import Color from '../images/Color Scheme.svg';
import Frame6 from '../images/Frame 6.svg';
import Trash from '../images/trash.svg';
import empty from '../images/empty.svg';
import Sun from '../images/sun.svg';
import TrashRed from '../images/trash-red.svg';
import Frame6Blue from '../images/Frame6-blue.svg';
import './style.css';

const MainNote = () => {
  const [noteText, setNoteText] = useState('');
  const [editIndex, setEditIndex] = useState(null);
  const [isClicked, setIsClicked] = useState(false);
  const [notes, setNotes] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [isBackgroundBlack, setIsBackgroundBlack] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [modalColor, setModalColor] = useState('white');
  const [trashHovered, setTrashHovered] = useState(false);
  const [editHovered, setEditHovered] = useState(false);




  const editNote = (index) => {
    setNotes((previous) => {
    
      const newNote = [...previous]

      newNote[index] = {
        ...newNote[index]
      
      }
      return newNote
    })
  }

  const editNoteHandler = (e) => {
    setEditIndex(e);
  }




  const openModal = () => {
    setShowModal(true);
  }

  const closeModal = () => {
    setShowModal(false);
  }



  
  const modalStyle = {
    background: isClicked ? 'var(--black)' : modalColor
  }

  const noteTitleChangeHandler = (event, index) => {
    const newNote = [...notes];
    newNote[index] = event.target.value;
    setNotes(newNote);
  };

  const deleteNoteHandler = (index) => {
    const newNote = [...notes];
    newNote.splice(index, 1);
    setNotes(newNote);
  };



  const clickBackgroundHandler = () => {
    setIsBackgroundBlack((prevState) => !prevState);
    if (modalColor === 'white') {
      setModalColor('black');
    } else {
      setModalColor('white');
    }
  };

  const toggleTextGrey = (index) => {
    setNotes((prevNotes) => {
      const updatedNotes = [...prevNotes];
      updatedNotes[index] = {
        ...updatedNotes[index],
        greyText: !updatedNotes[index].greyText // Toggle the 'greyText' property
      };
      return updatedNotes;
    });
  };

  const addNoteHandler = () => {
    if (noteText.trim() !== '') {
      setNotes([...notes, { content: noteText, ticked: false, greyText: false }]);
      setNoteText('');
      setShowModal(false);
    }
  };

  const filteredNotes = notes.filter((note) =>
    note.content.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className='Main-light' style={{ background: isBackgroundBlack ? 'var(--black, #252525)' : '' }}>
      <div className='CONTAINER-wrapper'>
        <div className='CONTAINER'>
          <div className='HEAD'>
            <div className={`text-wrapper ${isBackgroundBlack ? 'white-text' : 'black-text'}`}>TODO LIST</div>
            <header className='header'>
              <div className={`search ${isBackgroundBlack ? 'white-background' : 'black-background'}`}>
                <input className='search-note' placeholder='Search note...' type='text' />
                <img className={`vector ${isBackgroundBlack ? 'black-vector' : 'white-vector'}`} alt='Vector' src={Vector}/>
              </div>
              <div className='select'>
                <div className='content'>
                  <div className='all'>ALL</div>
                  <img className='chevron-top' alt='Chevron top' src={Chevron} />
                </div>
              </div>
              <div className='color-scheme'>
                <img className='img' alt='img' src={isBackgroundBlack ? Sun : Color} onClick={clickBackgroundHandler} style={isClicked ? ({backgroundColor: `--black`}) :({backgroundColor: `--white`}) }/>
              </div>
            </header>
          </div>
          <div className='BODY'>
            <div className='add-button' onClick={openModal}>
              <img className='vector-2' alt='Vector' src={Add} />
            </div>
            {showModal && (
              <div className='modal'>
                <div className='modal-content' style={{ background: isClicked ? 'var(--black)' : modalColor }}>
                  <h2 className={`new-note ${isBackgroundBlack ? 'white-text' : 'black-text'}`}>NEW NOTE</h2>
                  <input
                    type='text'
                    placeholder='Input your note...'
                    value={noteText}
                    className='Input-note'
                    onChange={(e) => setNoteText(e.target.value)}
                  />
                  <div className='button-container'>
                    <button className={`cancel ${isBackgroundBlack ? 'white-back' : 'black-back'}`} onClick={closeModal}>
                      Cancel
                    </button>
                    <button className='apply' onClick={addNoteHandler}>
                      Apply
                    </button>
                  </div>
                </div>
              </div>
            )}
            <div className='LIST'>
              {filteredNotes.length === 0 ? (
                <div style={{ textAlign: 'center' }}>
                  <img src={empty} className='empty' alt='Empty' />
                  <h2 className={isBackgroundBlack ? 'white-text' : 'black-text'}>No matching notes...</h2>
                </div>
              ) : (
                filteredNotes.map((note, index) => (
                  <div
                    key={index}
                    className={`note ${note.ticked ? 'ticked' : ''}`}
                    style={{ marginTop: '50px' }}
                  >
                    <div
                      className={`rectangle ${note.ticked ? 'purple' : ''}`}
                      onClick={() => toggleTextGrey(index)}
                    >
                      <input type="checkbox" id="rectangle"></input>
                      <span className={note.greyText ? 'grey-text' : ''}>
                        {note.content}
                      </span>
                    </div>
                    {editIndex === index ? (
          <input
            type='text'
            value={note}
            onChange={(e) => noteTitleChangeHandler(e, index)}
            onBlur={() => setEditIndex(null)} 
          />
        ) : (
          <div className=''>{note}</div>
        )}
        <div className='options'>
          <img
            className='img-2'
            alt='Frame'
            src={editHovered ? Frame6 : Frame6Blue}
            onMouseEnter={() => setEditHovered(true)}
            onMouseLeave={() => setEditHovered(false)}
            onClick={() => editNoteHandler(index)}
          />
          <img
            className='img-2 trash'
            alt='Trash svgrepo com'
            src={trashHovered ? TrashRed : Trash}
            onMouseEnter={() => setTrashHovered(true)}
           onMouseLeave={() => setTrashHovered(false)}
           onClick={() => deleteNoteHandler(index)}
          />
        </div>
      </div>
    ))
  )}
                 
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainNote;
